from flask import Flask, render_template
from chatterbot import ChatBot
from flask import request
from flask_cors import CORS
from chatterbot.trainers import ChatterBotCorpusTrainer


import json
#import MySQLdb
import re

data2={"conversation":[]}
#data2["conversation"]=[];
new_arr=[]
 


app = Flask(__name__)
CORS(app)
english_bot = ChatBot("English Bot")
english_bot.set_trainer(ChatterBotCorpusTrainer)
english_bot.train("chatterbot.corpus.zenrays")


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/sign_users",methods = ['POST', 'GET'])
def get_raw_response():
    query=request.args.get('name')
    response = str(english_bot.get_response(query))
    print("response"+response)
    if response == "Sorry i couldn't get what you told.Please train me.":
        file = open('C:\\Users\\Ankit.Kumar\\flask_git\\chatterbot\\corpus\\data\\zenrays\\test.json','w') 
        file.write(query) 
        file.close() 
    return response


@app.route("/train_users",methods = ['POST', 'GET'])
def get_train_response():
    print("Inside training")
    queryAnswer=request.args.get('trainAnswer')
    print("Got the answer")
    file = open('C:\\Users\\Ankit.Kumar\\flask_git\\chatterbot\\corpus\\data\\zenrays\\test.json', 'r') 
    question = file.readline()
    fileOne = open('C:\\Users\\Ankit.Kumar\\flask_git\\chatterbot\\corpus\\data\\zenrays\\zenrays.corpus.json', 'r')
    content = fileOne.readline()
    contents.insert(index, value)
    file = open('C:\\Users\\Ankit.Kumar\\flask_git\\chatterbot\\corpus\\data\\zenrays\\zenrays.corpus.json', 'w')
    contents = "["+question+","+queryAnswer+"]".join(contents)
    file.write(contents)
    file.close()    
    print("Written to file")
    return "Successfully  trained"


if __name__ == "__main__":
    app.run(host='0.0.0.0',port=5004)
