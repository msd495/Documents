(function () {
  'use strict';

  describe('Give it some context', function () {
	  
	  describe('Genrator testing',function(){
		  
		  it("can buils an iterator", function(){
			  
			  let numbers = function*(start, end){ 
				  for(let i =start;i<=end;i++){
					  yield i;
				  }
			  }
			  
			  let sum = 0;
			  for(let n of numbers(1,10)){
				  sum+=n;
			  }
			  expect(sum).toBe(55);
			  
		  })

			it("should contain zero", function(){
				var set = new Set();
				expect(set.size).toBe(0);
						  
			})

			it("should contain One item", function(){
				var set = new Set();
				set.add("1");
				set.add(3);
				expect(set.size).toBe(2);
						  
			})	

            it("should allow objects", function(){
				var set = new Set();
				var key = {};
				set.add("1");
				set.add(3);
				set.add(key);
				expect(set.has(key)).toBe(true);
						  
			})	

            it("should contain items", function(){
				var set = new Set([1,2,3]);
				expect(set.has(1)).toBe(true);
				expect(set.has(2)).toBe(true);
				expect(set.has(3)).toBe(true);
			})	


             it("should not allow duplicate  values", function(){
				var set = new Set();
				set.add(1);
				set.add(1);
				expect(set.size).toBe(1);
			
			})		

            it("should not contain items after clear is called", function(){
				var set = new Set();
				set.add(1);
				set.add(2);
				set.clear();
				expect(set.size).toBe(0);
			})	

             it("should not contain deleted item after delete is called", function(){
				var set = new Set();
				set.add(1);
				set.delete(1);
				set.add(2);
				expect(set.size).toBe(1);
			})


             it("map properties", function(){
				var map = new Map();
				map.set("tim",	 23);
				expect(map.size).toBe(1);
			})					
	  
	          it("map iterations", function(){
				var map = new Map();
				map.set("tim",	 23);
				map.set("tim1",	 21);
				map.set("tim2",	 22);
				var count = 0;
				map.forEach((key, value) => {
				return count++;
				});
				expect(count).toBe(3);
			})	

             it("find function Array", function(){
				var arra = [1,2,3];
				var found = arra.find(item => item>1);
				expect(found).toBe(2);
			})

			 it("find Index function Array", function(){
				var arra = [1,2,3];
			    var found = arra.findIndex(item => item>1);
				expect(found).toBe(1);
			})	

			it("Fill function Array", function(){
				var arra = [1,2,3];
				var found = arra.fill('a',2);
				expect(found).toEqual([1,2,'a']);
			})
	        it("Create new Array", function(){
				var arra = new Array(1);// Array with one index
				var arra1 = new Array(1,2,3)// Array with 3 elements
				var found = arra.fill('a');
				expect(found).toEqual(['a']);
			})	
            it("Create Array using Array.from", function(){
				var arrayLike = document.querySelectorAll('div');
				//expect(arrayLike.forEach).toBe(undefined);
				
				var fromArray = Array.from(arrayLike);
				expect(fromArray.forEach).toBeDefined();
			})	
            it("Create enteries in Array", function(){
			     var p = [1,2,3];
				 var enteries = p.entries();
				 
				 var firstEntry = enteries.next().value;
				 expect(firstEntry[0]).toBe(0);
				 expect(firstEntry[1]).toBe(1);
			})
            it("Create Keys in Array", function(){
			     var p = [1,2,3];
				 var enteries = p.keys();
				 
				 var firstEntry = enteries.next().value;
				 expect(firstEntry).toBe(0);
			})	
            it("Object is function", function(){
			     expect(-0 === 0).toBe(true);
				 expect(Object.is(-0,0)).toBe(false);
				 expect(NaN === NaN).toBe(false);
				 expect(Object.is(NaN,NaN)).toBe(true);
			})
           it("Mixins", function(){
			     var shark = {
					 bite:function(target){
						 target.hurt = true
					 }
				 }
				 
				 var laser = {
					 pewpew : function(target){
					   target.explode = true;
					 }
				 }
				 
				 Object.assign(shark, laser);
			})	
           it("new shorthand method for assigning properties", function(){
			     var model = 'ford';
				 var year = 1969
				 
				 var classic = {model:model,year:year};
				 
				 var newWay = {model,year};
				 
				 expect(newWay.model).toBe('ford');
				 expect(newWay.year).toBe(1969);
			})			
	  });
	  

    
  });
})();
